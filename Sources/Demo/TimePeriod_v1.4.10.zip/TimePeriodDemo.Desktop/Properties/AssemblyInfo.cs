// -- FILE ------------------------------------------------------------------
// name       : AssemblyInfo.cs
// project    : Itenso Time Period
// created    : Jani Giannoudis - 2011.02.18
// language   : C# 4.0
// environment: .NET 2.0
// copyright  : (c) 2011-2012 by Itenso GmbH, Switzerland
// --------------------------------------------------------------------------
using System;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.Permissions;

// General Information about an assembly is controlled through the following
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle( "Itenso Time Period Demo" )]
[assembly: AssemblyDescription( "Itenso Time Period Demo" )]
[assembly: AssemblyConfiguration( "" )]
[assembly: AssemblyCompany( "Itenso GmbH" )]
[assembly: AssemblyProduct( "Itenso Time Period" )]
[assembly: AssemblyCopyright( "Copyright © Itenso GmbH 2011-2012" )]
[assembly: AssemblyTrademark( "" )]
[assembly: AssemblyCulture( "" )]
[assembly: ComVisible( false )]
[assembly: SecurityPermission( SecurityAction.RequestMinimum, Assertion = true )]
[assembly: CLSCompliant( true )]

// -- EOF -------------------------------------------------------------------
