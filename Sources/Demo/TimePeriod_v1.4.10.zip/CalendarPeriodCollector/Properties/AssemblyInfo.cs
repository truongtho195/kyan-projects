// -- FILE ------------------------------------------------------------------
// name       : AssemblyInfo.cs
// project    : Itenso Time Period
// created    : Jani Giannoudis - 2011.02.18
// language   : C# 4.0
// environment: .NET 2.0
// copyright  : (c) 2011-2012 by Itenso GmbH, Switzerland
// --------------------------------------------------------------------------
using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle( "Itenso Time Period Demo" )]
[assembly: AssemblyDescription( "Itenso Time Period Demo" )]
[assembly: AssemblyConfiguration( "" )]
[assembly: AssemblyCompany( "Itenso GmbH" )]
[assembly: AssemblyProduct( "Itenso Time Period" )]
[assembly: AssemblyCopyright( "Copyright © Itenso GmbH 2011-2012" )]
[assembly: AssemblyTrademark( "" )]
[assembly: AssemblyCulture( "" )]
[assembly: ComVisible( false )]
[assembly: Guid( "d0f04b31-c716-4ced-b5be-230bdd1489a4" )]

// -- EOF -------------------------------------------------------------------

